# COMP 3512 (Fall 2022)
### Assignment #2: JavaScript

**Please view `COMP3512 Assignment 2.pdf` for instructions** <br>
**GitHub Pages link https://jpope229.github.io/COMP3512F2022Asg2/**
  
